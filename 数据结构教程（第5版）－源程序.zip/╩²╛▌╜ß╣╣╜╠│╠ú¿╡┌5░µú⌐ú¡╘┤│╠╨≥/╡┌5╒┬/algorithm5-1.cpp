//【例5.1】的算法：求n!的递归算法
#include <stdio.h>
int fun(int n)
{
	if (n==1) 					//语句1
		return(1);				//语句2
	else 						//语句3
		return(fun(n-1)*n);		//语句4
}
int main()
{
	printf("10!=%d\n",fun(10));
	return 1;
}